Performance Bounceback README
Udacity Project 8B Submission
By: Diego Gile

Released: 9-17-2017
Re-Released: 10-4-2017
Versions: Unity Version 2017.1.1f1
HMD Tested: HTC VIVE

Final Scene: Scene0_optimized

Thanks for your feedback!  I believe I've resolved all issues and appreciate the thoughtful code review as I was able to learn of some bad habits I was developing.  I also tried to incorporate all suggested changes, though I admit more optimization could be done.  Hope this release meets the requirements!

-------------------------------------------------------------------

I believe the trampoline challenge has been optimized to the required specifications.  I've tested this scene with a standalone build as well as in the editor and achieved 90+ FPS even when there were several dozen objects in view.

Thank you for your feedback!