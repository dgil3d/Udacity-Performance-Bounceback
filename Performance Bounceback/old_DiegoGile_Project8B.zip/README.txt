Performance Bounceback README
Udacity Project 8B Submission
By: Diego Gile

Released: 9-17-2017
Versions: Unity Version 5.6.3
HMD Tested: HTC VIVE

Final Scene: Scene0_optimized

I believe the trampoline challenge has been optimized to the required specifications.  I've tested this scene with a standalone build as well as in the editor and achieved 90+ FPS even when there were several dozen objects in view. I believe the Object Pooling can use additional tweaking and look forward to your comments.

Thank you for your feedback!