﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

    public int score;

	// Use this for initialization
	void Start () {
		
	}
	
}
